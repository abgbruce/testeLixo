
# ProductAvailability

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**productId** | **String** | A unique identifier for the product |  [optional]
**name** | **String** | SKU identifier |  [optional]
**skuName** | **String** | SKU Name |  [optional]
**skuDescription** | **String** | A short description of the product |  [optional]
**availableQuantity** | **Integer** | available quantity |  [optional]
**createdDate** | [**BigDecimal**](BigDecimal.md) | Created Date |  [optional]
**expiryDate** | [**BigDecimal**](BigDecimal.md) | Expiration Date |  [optional]
**images** | **List&lt;String&gt;** | An array of image objects |  [optional]
**discount** | **Float** | Discount |  [optional]
**price** | **Float** | Price |  [optional]
**inventoryType** | **String** | Inventory Type |  [optional]



