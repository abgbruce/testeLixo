
# ProductDetail

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **String** | A unique identifier for the product |  [optional]
**productName** | **String** | Display name of the product |  [optional]
**shortDescription** | **String** | A short description of the product |  [optional]
**images** | **List&lt;String&gt;** | An array of image objects |  [optional]
**category** | **List&lt;String&gt;** | An array of category objects |  [optional]
**overallRating** | **Float** | Overall customer rating for the product |  [optional]



