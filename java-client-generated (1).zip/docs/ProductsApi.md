# ProductsApi

All URIs are relative to *https://bruce1-eval-test.apigee.net/v1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**createNewProduct**](ProductsApi.md#createNewProduct) | **POST** /products | Create new product
[**getAllProducts**](ProductsApi.md#getAllProducts) | **GET** /products | Get All Product Details
[**getProduct**](ProductsApi.md#getProduct) | **GET** /products/{product_id} | Product Detail
[**getProductAvailability**](ProductsApi.md#getProductAvailability) | **GET** /products/{product_id}/availability | Product Availability
[**updateProduct**](ProductsApi.md#updateProduct) | **PUT** /products/{product_id} | Update Product


<a name="createNewProduct"></a>
# **createNewProduct**
> ProductDetail createNewProduct(body)

Create new product

&lt;p&gt;Create Product&lt;/p&gt; Create new product

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.ProductsApi;


ProductsApi apiInstance = new ProductsApi();
NewProductDetail body = new NewProductDetail(); // NewProductDetail | New Product to be added to the store
try {
    ProductDetail result = apiInstance.createNewProduct(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ProductsApi#createNewProduct");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**NewProductDetail**](NewProductDetail.md)| New Product to be added to the store |

### Return type

[**ProductDetail**](ProductDetail.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json; charset=utf-8

<a name="getAllProducts"></a>
# **getAllProducts**
> ProductDetails getAllProducts()

Get All Product Details

&lt;p&gt;Product Detail&lt;/p&gt; Detailed list of all Products.

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.ProductsApi;


ProductsApi apiInstance = new ProductsApi();
try {
    ProductDetails result = apiInstance.getAllProducts();
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ProductsApi#getAllProducts");
    e.printStackTrace();
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**ProductDetails**](ProductDetails.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json; charset=utf-8

<a name="getProduct"></a>
# **getProduct**
> ProductDetail getProduct(productId)

Product Detail

&lt;p&gt;Product Detail&lt;/p&gt; Detailed list of Product given the productId.

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.ProductsApi;


ProductsApi apiInstance = new ProductsApi();
String productId = "productId_example"; // String | Product identifier
try {
    ProductDetail result = apiInstance.getProduct(productId);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ProductsApi#getProduct");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **productId** | **String**| Product identifier |

### Return type

[**ProductDetail**](ProductDetail.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json; charset=utf-8

<a name="getProductAvailability"></a>
# **getProductAvailability**
> ProductAvailability getProductAvailability(productId)

Product Availability

&lt;p&gt;Product Availability&lt;/p&gt; Detailed info of Product availability for the given productId.

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.ProductsApi;


ProductsApi apiInstance = new ProductsApi();
String productId = "productId_example"; // String | Product identifier
try {
    ProductAvailability result = apiInstance.getProductAvailability(productId);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ProductsApi#getProductAvailability");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **productId** | **String**| Product identifier |

### Return type

[**ProductAvailability**](ProductAvailability.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json; charset=utf-8

<a name="updateProduct"></a>
# **updateProduct**
> ProductDetail updateProduct(productId, body)

Update Product

&lt;p&gt;Update Product&lt;/p&gt; Update product for a given productId

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.ProductsApi;


ProductsApi apiInstance = new ProductsApi();
String productId = "productId_example"; // String | Product identifier
NewProductDetail body = new NewProductDetail(); // NewProductDetail | Product to be updated
try {
    ProductDetail result = apiInstance.updateProduct(productId, body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ProductsApi#updateProduct");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **productId** | **String**| Product identifier |
 **body** | [**NewProductDetail**](NewProductDetail.md)| Product to be updated |

### Return type

[**ProductDetail**](ProductDetail.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json; charset=utf-8

